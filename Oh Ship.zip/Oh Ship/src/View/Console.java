package View;
public class Console {

	public void print(String string)
	{
		System.out.print(string);
	}
	
	public void println(String string)
	{
		System.out.println(string);
	}
}

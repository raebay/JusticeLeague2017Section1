// this is a test comment for gilad


public abstract class Character 
{

	public int health = 10; 

	public Character()
	{
		
	}
	
	public Character(int health) 
	{
		this.health = health; 
	}
	
	public void attack()
	{
		
	}
	
	public void receiveDamage()
	{
		
	}

}

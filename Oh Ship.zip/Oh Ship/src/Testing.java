import java.util.Iterator;

public class Testing extends Room
{

    
	public static void main(String[] args) 
	{

		Room currentRoom = new Room();
		
		Iterator<Room> iterator = rooms.iterator();
		
			while(iterator.hasNext())
		{
			Room temp = new Room(); 	 
			temp = iterator.next(); 
			
			if(currentRoom.rID !=temp.rID)
			{
			currentRoom = temp.findRoom("1.a");
			}
			else
			{
			iterator.next(); 
			}
		
		}

	}


}
	


import java.util.ArrayList;

public class Inventory
{
	public ArrayList items = new ArrayList(); 
	public Item equipped; 

	public Inventory() 
	{
	}

}

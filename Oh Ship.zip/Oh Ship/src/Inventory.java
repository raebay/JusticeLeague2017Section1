import java.util.ArrayList;

import Model.Item;

public class Inventory
{
	public ArrayList items = new ArrayList(); 
	public Item equipped; 

	public Inventory() 
	{
	}

}

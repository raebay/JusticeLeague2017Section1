
public class Monster extends Character 
{
	public String name = "";
	public String descripton = "";
	public boolean isDefeated = false; 

	public Monster(int health, String name, String description, boolean isDefeated) 
	{
		super(health);
		this.name = name; 
		this.descripton = description; 
		this.isDefeated = isDefeated; 
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getDescripton() 
	{
		return descripton;
	}

	public void setDescripton(String descripton) 
	{
		this.descripton = descripton;
	}

	public boolean isDefeated()
	{
		return isDefeated;
	}

	public void setDefeated(boolean isDefeated) 
	{
		this.isDefeated = isDefeated;
	}
	
	public void die()
	{
		
	}

}


public abstract class Character 
{

	public int health = 10; 
	
	public Character(int health) 
	{
		this.health = health; 
	}
	
	public void attack()
	{
		
	}
	
	public void receiveDamage()
	{
		
	}

}

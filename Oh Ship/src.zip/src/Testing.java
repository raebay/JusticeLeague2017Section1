

public class Testing extends Room
{

    
	public static void main(String[] args) 
	{

		Room currentRoom = new Room(); 
		
			for(Room temps: rooms)
		{
			currentRoom = temps.findRoom("1.a");
		}

	}


}
	


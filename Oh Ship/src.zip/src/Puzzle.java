
public class Puzzle 
{
	public boolean isSoloved = false; 
	public String puzzleHint = "";
	public String puzzleDescription = "";

	public Puzzle(boolean isSolved, String puzzleHint, String puzzleDescription) 
	{
		this.isSoloved = isSolved; 
		this.puzzleDescription = puzzleDescription; 
		this.puzzleHint = puzzleHint; 
	}

	public boolean isSoloved() 
	{
		return isSoloved;
	}

	public void setSoloved(boolean isSoloved) 
	{
		this.isSoloved = isSoloved;
	}

	public String getPuzzleHint() 
	{
		return puzzleHint;
	}

	public void setPuzzleHint(String puzzleHint) 
	{
		this.puzzleHint = puzzleHint;
	}

	public String getPuzzleDescription() 
	{
		return puzzleDescription;
	}

	public void setPuzzleDescription(String puzzleDescription) 
	{
		this.puzzleDescription = puzzleDescription;
	}
	
	public void checkAnswer()
	{
		
	}
	
	public void examine()
	{
		
	}
	
	public String obtainHint()
	{
		return puzzleHint; 
	}
	
	public void ignorePuzzle()
	{
		
	}

}
